﻿using System;
using Api.DTOs;
using Database;
using Microsoft.AspNetCore.Mvc;

namespace Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClassesController : ControllerBase
    {
        private readonly ApiContext _context;

        public ClassesController(ApiContext context)
        {
            _context = context;
        }

        [HttpPost]
        public IActionResult Insert(ClassDto classDto)
        {
            throw new NotImplementedException();
        }

        [HttpPost]
        [Route("{classId}/students/{studentId}")]
        public IActionResult EnrollStudent(int classId, int studentId)
        {
            throw new NotImplementedException();
        }

        [HttpGet]
        [Route("{id}")]
        public ClassDto Get(int id)
        {
            throw new NotImplementedException();
        }
    }
}