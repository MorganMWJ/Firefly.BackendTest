﻿using System;
using Api.DTOs;
using Database;
using Microsoft.AspNetCore.Mvc;

namespace Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentsController : Controller
    {
        private readonly ApiContext _context;

        public StudentsController(ApiContext context)
        {
            _context = context;
        }

        [HttpPost]
        public IActionResult Insert(StudentDto student)
        {
            throw new NotImplementedException();
        }

        [HttpGet]
        [Route("{id}")]
        public StudentDto Get(int id)
        {
            throw new NotImplementedException();
        }
    }
}