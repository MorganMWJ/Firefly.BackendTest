﻿using System;
using Api.DTOs;
using Database;
using Microsoft.AspNetCore.Mvc;

namespace Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TeachersController : ControllerBase
    {
        private readonly ApiContext _context;

        public TeachersController(ApiContext context)
        {
            _context = context;
        }

        [HttpPost]
        public IActionResult Insert(TeacherDto teacher)
        {
            throw new NotImplementedException();
        }

        [HttpPost]
        [Route("{teacherId}/classes/{classId}")]
        public IActionResult AssignClass(int teacherId, int classId)
        {
            throw new NotImplementedException();
        }

        [HttpGet]
        [Route("{id}")]
        public TeacherDto Get(int id)
        {
            throw new NotImplementedException();
        }
    }
}