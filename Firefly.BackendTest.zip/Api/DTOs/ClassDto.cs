﻿namespace Api.DTOs
{
    public class ClassDto
    {
        public string Name { get; set; }
        public int Capacity { get; set; }
    }
}
