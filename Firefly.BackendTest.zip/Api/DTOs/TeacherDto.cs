﻿namespace Api.DTOs
{
    public class TeacherDto
    {
        public string Name { get; set; }
        public string Email { get; set; }
    }
}
