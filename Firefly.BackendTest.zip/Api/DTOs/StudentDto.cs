﻿namespace Api.DTOs
{
    public class StudentDto
    {
        public string Name { get; set; }
        public string Email { get; set; }
    }
}
