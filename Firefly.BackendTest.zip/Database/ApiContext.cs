﻿using Domain.Model;
using Microsoft.EntityFrameworkCore;

namespace Database
{
    public class ApiContext : DbContext
    {
        public DbSet<Student> Students { get; set; }
        public DbSet<Class> Classes { get; set; }
        public DbSet<Teacher> Teachers { get; set; }
    }
}
