﻿using System.Collections.Generic;

namespace Domain.Model
{
    public class Class
    {
        public int Id { get; }
        public string Name { get; }
        public int Capacity { get; set; }

        public Teacher Teacher { get; set; }
        public ICollection<Student> Students { get; set; }

        public Class(int id, string name)
        {
            Id = id;
            Name = name;
        }
    }
}
