﻿using System.Collections.Generic;

namespace Domain.Model
{
    public class Teacher
    {
        public int Id { get; }
        public string Name { get; }

        public virtual ICollection<Class> Classes { get; set; }

        public Teacher(int id, string name)
        {
            Id = id;
            Name = name;
        }
    }
}
