﻿using System.Collections.Generic;

namespace Domain.Model
{
    public class Student
    {
        public int Id { get; }
        public string Name { get; }
        public string Email { get; }

        public IEnumerable<Class> Classes { get; set; }

        public Student(int id, string name, string email)
        {
            Id = id;
            Name = name;
            Email = email;
        }
    }
}
